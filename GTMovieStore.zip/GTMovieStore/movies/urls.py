from django.urls import path
from . import views

urlpatterns = [
    # Home page that lists all movies
    path('', views.home, name='home'),

    # Detailed view for a specific movie
    path('movie/<int:id>/', views.movie_detail, name='movie_detail'),

    # Add a route for searching movies
    path('search/', views.search_movies, name='search_movies'),

    # Add a route for about page
    path('about/', views.about, name='about'),
]
