from django.shortcuts import render, get_object_or_404
from django.db import models  # Import models for advanced querying
from .models import Movie

def home(request):
    movies = Movie.objects.all().order_by('-release_date')  # Ordered by newest movies first
    return render(request, 'movies/home.html', {'movies': movies})

def movie_detail(request, id):
    movie = get_object_or_404(Movie, id=id)
    return render(request, 'movies/movie_detail.html', {'movie': movie})

def search_movies(request):
    query = request.GET.get('q', '')  # Get the search query
    if query:
        movies = Movie.objects.filter(
            models.Q(title__icontains=query) |  # Search by title
            models.Q(description__icontains=query) |  # Search by description
            models.Q(genre__icontains=query)  # Search by genre
        )
    else:
        movies = Movie.objects.none()  # No results if no query
    return render(request, 'movies/search_results.html', {'movies': movies, 'query': query})

def about(request):
    return render(request, 'movies/about.html')
